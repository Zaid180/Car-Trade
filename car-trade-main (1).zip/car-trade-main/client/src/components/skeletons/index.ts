import CarSkeleton from './carSkeleton';
import TableSkeleton from './tableSkeleton';

export { CarSkeleton, TableSkeleton };
