import httpInstance from './axiosConfig';

export default httpInstance;
