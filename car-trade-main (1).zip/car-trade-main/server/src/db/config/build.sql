CREATE DATABASE good_cars;

CREATE USER team3 with superuser password '918';

ALTER DATABASE good_cars OWNER to team3;