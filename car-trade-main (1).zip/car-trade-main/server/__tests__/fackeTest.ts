import { expect, test } from '@jest/globals';

test('adds 1 + 2 to equal 3', () => {
  expect(1).toBe(1);
});
